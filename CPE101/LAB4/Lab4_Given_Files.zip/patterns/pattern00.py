# Lab 4
#
# Name: 
# Instructor: Sussan Einakian
# Section: 

import driver

def letter(row, col):
	return 'A'

if __name__ == '__main__':
	driver.comparePatterns(letter)
